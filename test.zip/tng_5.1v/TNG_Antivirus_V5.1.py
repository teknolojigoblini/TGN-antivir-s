#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
████████╗███╗   ██╗ ██████╗     █████╗ ███╗   ██╗████████╗██╗██╗   ██╗██╗██████╗ ██╗   ██╗███████╗
╚══██╔══╝████╗  ██║██╔════╝    ██╔══██╗████╗  ██║╚══██╔══╝██║██║   ██║██║██╔══██╗██║   ██║██╔════╝
   ██║   ██╔██╗ ██║██║         ███████║██╔██╗ ██║   ██║   ██║██║   ██║██║██████╔╝██║   ██║███████╗
   ██║   ██║╚██╗██║██║         ██╔══██║██║╚██╗██║   ██║   ██║╚██╗ ██╔╝██║██╔══██╗██║   ██║╚════██║
   ██║   ██║ ╚████║╚██████╗    ██║  ██║██║ ╚████║   ██║   ██║ ╚████╔╝ ██║██║  ██║╚██████╔╝███████║
   ╚═╝   ╚═╝  ╚═══╝ ╚═════╝    ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═══╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝
   
   TNG ANTİVİRÜS V5.1 - TAM OTOMATİK KORUMA
   Windows XP Horror Edition | Petya | SalineWin | MEMZ | Bootkit | EFI Rootkit
   Geliştirici: TEKNOLOJIGOBLINI
"""

import os
import sys
import time
import json
import math
import struct
import hashlib
import datetime
import platform
import subprocess
import importlib
import socket
import re
import threading
import shutil
import webbrowser
import tempfile
import zipfile
from pathlib import Path

# ============================================================================
# OTOMATİK MODÜL YÜKLEYİCİ
# ============================================================================

class ModuleLoader:
    @staticmethod
    def check_and_install():
        print("\n" + "="*60)
        print("📦 TNG Modül Yükleyici")
        print("="*60)
        
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except:
            pass
        
        try:
            global psutil
            import psutil
            print("✅ psutil yüklü")
        except ImportError:
            print("⚠️ psutil kuruluyor...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", "psutil"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            import psutil
        
        return True

if not ModuleLoader.check_and_install():
    print("❌ Modül yüklenemedi!")
    sys.exit(1)

# ============================================================================
# RENK SINIFI
# ============================================================================

try:
    import colorama
    colorama.init()
    RENK_VAR = True
except:
    RENK_VAR = False

class Renk:
    BAS = '\033['
    YESIL = f'{BAS}92m'
    SARI = f'{BAS}93m'
    KIRMIZI = f'{BAS}91m'
    MAVI = f'{BAS}94m'
    MOR = f'{BAS}95m'
    CYAN = f'{BAS}96m'
    BEYAZ = f'{BAS}97m'
    TURUNCU = f'{BAS}38;5;208m'
    PEMBE = f'{BAS}38;5;205m'
    SON = f'{BAS}0m'

def c(text, renk):
    return f"{renk}{text}{Renk.SON}" if RENK_VAR else text

GELISTIRICI = {
    "isim": "TEKNOLOJIGOBLINI",
    "instagram": "@TEKNOLOJIGOBLINI",
    "youtube": "@teknolojigoblini",
    "versiyon": "5.1.0"
}

def bytes_insan_oku(bytes_deger):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_deger < 1024.0:
            return f"{bytes_deger:.2f} {unit}"
        bytes_deger /= 1024.0
    return f"{bytes_deger:.2f} TB"

# ============================================================================
# TÜM TEHLİKELİ VİRÜSLER (Windows XP Horror Edition, Petya, SalineWin, MEMZ, vs.)
# ============================================================================

TEHLIKELI_VIRUSLER = {
    # ========== WINDOWS XP HORROR EDITION VİRÜSLERİ ==========
    "windows_xp_horror": {
        "isimler": [
            "windows xp horror", "xp horror", "horror edition", "xp_horror",
            "horror_xp", "windowsxp_horror", "xp_horror_edition"
        ],
        "dosya_isimleri": [
            "xp_horror.exe", "horror_xp.exe", "windowsxp_horror.exe",
            "setup_horror.exe", "xp_horror_installer.exe"
        ],
        "aciklama": "Windows XP Horror Edition - Sistem dosyalarını bozan trojan",
        "risk": 100,
        "etki": "Sistem dosyaları bozulur, mavi ekran, sürekli çökme"
    },
    
    # ========== SALINEWIN.EXE (Kahkahalı Virüs) ==========
    "salinewin": {
        "isimler": [
            "salinewin", "salinewin.exe", "saline_win", "salina",
            "kahkaha", "laughing", "haha", "hehe"
        ],
        "dosya_isimleri": [
            "salinewin.exe", "saline_win.exe", "saline.exe",
            "kahkaha.exe", "laughing_virus.exe"
        ],
        "aciklama": "SalineWin.exe - Ekranda kahkaha sesi çıkaran, sistemde gezinme engelleyen virüs",
        "risk": 95,
        "etki": "Mouse/klavye kilidi, kahkaha sesi, sistem donması"
    },
    
    # ========== PETYA RANSOMWARE ==========
    "petya": {
        "isimler": [
            "petya", "notpetya", "petya_ransomware", "petya.exe",
            "petja", "petya_mbr", "mbrlock"
        ],
        "dosya_isimleri": [
            "petya.exe", "notpetya.exe", "petya_ransom.exe",
            "order_doc.exe", "2017_ene_compromiso.exe"
        ],
        "aciklama": "Petya - MBR'yi şifreleyen ransomware (2016-2017 saldırısı)",
        "risk": 100,
        "etki": "MBR şifrelenir, sistem açılmaz, fidye ister"
    },
    
    # ========== MEMZ TROJAN ==========
    "memz": {
        "isimler": [
            "memz", "memz.exe", "memz.dmg", "memz_trojan", "memz_virus",
            "memz_trojan.exe", "dankmemz", "memz_destroyer"
        ],
        "dosya_isimleri": [
            "memz.exe", "memz_trojan.exe", "dankmemz.exe",
            "memz_destroyer.exe", "memz_redpill.exe"
        ],
        "aciklama": "MEMZ - MBR/EFI'yi silen, BIOS'a zarar veren çok tehlikeli trojan",
        "risk": 100,
        "etki": "MBR/EFI silme, BIOS bozma, kalıcı donanımsal hasar"
    },
    
    # ========== BOOTKIT / MBR VİRÜSLERİ ==========
    "bootkit": {
        "isimler": [
            "bootkit", "mbr", "vbr", "bootsect", "bootice", "bootmgr",
            "mbr_bootkit", "boot_rootkit", "mbr_virus"
        ],
        "dosya_isimleri": [
            "bootkit.exe", "mbr.exe", "bootsect.exe", "bootice.exe",
            "mbr_fix.exe", "boot_fixer.exe"
        ],
        "aciklama": "Bootkit - Önyükleme sektörüne bulaşan rootkit",
        "risk": 100,
        "etki": "Boot sektörü bozulma, sistem açılmama, kalıcı enfeksiyon"
    },
    
    # ========== EFI / UEFI ROOTKIT ==========
    "efi_rootkit": {
        "isimler": [
            "efi", "uefi", "spi", "flash", "firmware", "bios",
            "efi_rootkit", "uefi_rootkit", "efi_hack", "bios_kill"
        ],
        "dosya_isimleri": [
            "efi.exe", "uefi_flash.exe", "bios_update.exe",
            "firmware_flash.exe", "spi_flash.exe"
        ],
        "aciklama": "EFI Rootkit - UEFI/BIOS firmware bulaşan rootkit",
        "risk": 100,
        "etki": "Donanımsal kalıcı hasar, BIOS bozulması"
    },
    
    # ========== DARK KNIGHT BOOTKIT ==========
    "dark_knight": {
        "isimler": [
            "darkknight", "dark_knight", "bkdr", "bootworm",
            "darknight", "knight_bootkit"
        ],
        "dosya_isimleri": [
            "darkknight.exe", "dark_knight.exe", "bkdr.exe",
            "knight_boot.exe", "nightmare_boot.exe"
        ],
        "aciklama": "Dark Knight - MBR/EFI bootkit (Derin sistem enfeksiyonu)",
        "risk": 100,
        "etki": "Kalıcı bootkit enfeksiyonu, sistem yeniden yüklemeyle bile temizlenemez"
    },
    
    # ========== CIH (CHERNOBYL) VİRÜS ==========
    "cih_chernobyl": {
        "isimler": [
            "cih", "chernobyl", "cih_virus", "chernobyl_virus",
            "win95.cih", "spacefiller"
        ],
        "dosya_isimleri": [
            "cih.exe", "chernobyl.exe", "cih_bios.exe",
            "spacefiller.exe", "win95_cih.exe"
        ],
        "aciklama": "CIH (Chernobyl) - BIOS'u silen efsanevi virüs (1998)",
        "risk": 100,
        "etki": "BIOS silinmesi, kalıcı donanımsal hasar, anakartın tuğlalanması"
    },
    
    # ========== STONED BOOT VİRÜS ==========
    "stoned_boot": {
        "isimler": [
            "stoned", "stoned_boot", "stoned_virus", "stoned_mbr",
            "stoned_bootkit", "marijuana"
        ],
        "dosya_isimleri": [
            "stoned.exe", "stoned_boot.exe", "stoned_mbr.exe"
        ],
        "aciklama": "Stoned Boot Virus - MBR'ye bulaşan klasik boot virüsü",
        "risk": 95,
        "etki": "MBR bozulması, 'Your PC is stoned' mesajı"
    },
    
    # ========== FORMAT C: VİRÜSLERİ ==========
    "format_killer": {
        "isimler": [
            "format", "format_c", "disk_killer", "hdd_killer",
            "zero_fill", "overwrite", "wiper"
        ],
        "dosya_isimleri": [
            "format_c.exe", "disk_killer.exe", "hdd_wiper.exe",
            "zero_fill.exe", "overwrite_disk.exe"
        ],
        "aciklama": "Format C: Virüsü - Sistemi formatlayan disk silici",
        "risk": 100,
        "etki": "Tüm disk silinmesi, veri kaybı, format"
    },
    
    # ========== SALAMANDA VİRÜS ==========
    "salamanda": {
        "isimler": [
            "salamanda", "salamander", "salamand", "salamandra",
            "salamanda_virus", "fire_salamander"
        ],
        "dosya_isimleri": [
            "salamanda.exe", "salamander.exe", "fire_salamander.exe"
        ],
        "aciklama": "Salamanda Virüs - Ekran görüntüsünü ters çeviren, sistemde gezinen virüs",
        "risk": 85,
        "etki": "Ekran ters dönme, mouse hareketleri ters, sistem karışması"
    },
    
    # ========== NYAN CAT VİRÜS ==========
    "nyancat": {
        "isimler": [
            "nyan", "nyancat", "nyan_cat", "rainbow_cat",
            "nyan_virus", "pop tart cat"
        ],
        "dosya_isimleri": [
            "nyancat.exe", "nyan_cat.exe", "rainbow_cat.exe",
            "nyan_virus.exe"
        ],
        "aciklama": "Nyan Cat Virüs - Ekranda Nyan Cat animasyonu gösteren zararlı",
        "risk": 70,
        "etki": "Sistem performans düşüşü, ekran kaplama, müzik çalma"
    },
    
    # ========== TİMURLENMİŞ VİRÜSLER ==========
    "timurlanmis": {
        "isimler": [
            "timurlanmis", "timur", "timurlu", "timurlanma",
            "timur_virus", "cengiz", "mongol"
        ],
        "dosya_isimleri": [
            "timurlanmis.exe", "timur.exe", "cengiz.exe",
            "mongol_killer.exe"
        ],
        "aciklama": "Timurlanmış Virüs - Sistem simgelerini değiştiren trojan",
        "risk": 75,
        "etki": "Simgeler değişir, duvar kağıdı silinir, sistem karışır"
    },
    
    # ========== DİĞER TROJAN VE BACKDOOR'LAR ==========
    "trojan_generic": {
        "isimler": [
            "trojan", "backdoor", "rat", "njrat", "quasar",
            "darkcomet", "nanocore", "cybergate", "poisonivy"
        ],
        "dosya_isimleri": [
            "trojan.exe", "backdoor.exe", "rat.exe", "server.exe",
            "client.exe", "svchost.exe", "winlogon.exe"
        ],
        "aciklama": "Genel Trojan/Backdoor - Uzaktan erişim sağlayan zararlı",
        "risk": 90,
        "etki": "Uzaktan kontrol, bilgi çalma, webcam erişimi"
    },
    
    # ========== AĞ SOLUCANLARI ==========
    "worm": {
        "isimler": [
            "blaster", "sasser", "conficker", "nimda",
            "code_red", "slammer", "msblast", "lovsan", "morris"
        ],
        "dosya_isimleri": [
            "msblast.exe", "lsass.exe", "blaster.exe", "sasser.exe",
            "conficker.exe", "nimda.exe", "code_red.exe"
        ],
        "aciklama": "Ağ Solucanı - Kendi kendine yayılan worm",
        "risk": 85,
        "etki": "Ağ trafiği artışı, sistem yavaşlaması, yayılma"
    },
    
    # ========== FİDYE YAZILIMLAR ==========
    "ransomware": {
        "isimler": [
            "wannacry", "wanna", "locky", "cryptolocker", "cerber",
            "teslacrypt", "torrentlocker", "lockbit", "blackcat",
            "revil", "conti", "maze", "ryuk"
        ],
        "dosya_isimleri": [
            "wannacry.exe", "locky.exe", "cryptolocker.exe",
            "decrypt.exe", "readme.txt", "help_decrypt.txt"
        ],
        "aciklama": "Ransomware - Dosyaları şifreleyip fidye isteyen yazılım",
        "risk": 100,
        "etki": "Dosyalar şifrelenir, erişilemez, bitcoin fidyesi"
    },
    
    # ========== ROOTKIT'LER ==========
    "rootkit": {
        "isimler": [
            "rootkit", "tdl", "tdss", "alureon", "mebroot",
            "sinowal", "necurs", "zeroaccess", "max", "phide"
        ],
        "dosya_isimleri": [
            "rootkit.sys", "tdl.sys", "tdss.sys", "mbr.sys",
            "driver.sys", "ntoskrnl.sys", "hal.dll"
        ],
        "aciklama": "Rootkit - Sisteme derinlemesine gizlenen zararlı",
        "risk": 100,
        "etki": "Sistemden tamamen gizlenme, antivirüs atlatma"
    },
    
    # ========== BOTNET'LER ==========
    "botnet": {
        "isimler": [
            "bot", "botnet", "cnc", "ddos", "flooder", "killer",
            "mirai", "qbot", "sality", "virut"
        ],
        "dosya_isimleri": [
            "bot.exe", "cnc.exe", "ddos.exe", "flooder.exe",
            "mirai.exe", "qbot.exe"
        ],
        "aciklama": "Botnet - DDoS saldırısı yapan bot ağı",
        "risk": 85,
        "etki": "DDoS saldırısı, ağ trafiği, gizli çalışma"
    },
    
    # ========== KEYLOGGER'LAR ==========
    "keylogger": {
        "isimler": [
            "keylogger", "spy", "tracker", "hawkeye", "refog",
            "flexispy", "mspy", "theonespy"
        ],
        "dosya_isimleri": [
            "keylogger.exe", "spy.exe", "logger.exe", "hook.dll",
            "systemdll32.exe", "keylog.exe", "keyboard.dll"
        ],
        "aciklama": "Keylogger - Tuş vuruşlarını kaydeden casus yazılım",
        "risk": 95,
        "etki": "Şifreler çalınır, kredi kartı bilgileri sızdırılır"
    },
    
    # ========== KRİPTO MADENCİLERİ ==========
    "cryptominer": {
        "isimler": [
            "xmrig", "miner", "cpuminer", "ethminer", "ccminer",
            "claymore", "nicehash", "nanominer", "t-rex", "gminer"
        ],
        "dosya_isimleri": [
            "xmrig.exe", "miner.exe", "cpuminer.exe", "ethminer.exe",
            "ccminer.exe", "claymore.exe", "nicehash.exe"
        ],
        "aciklama": "Cryptominer - İzinsiz kripto para madencisi",
        "risk": 80,
        "etki": "CPU %100 kullanımı, elektrik faturası artışı, sistem yavaşlaması"
    }
}

# ============================================================================
# OTOMATİK YEDEKLEME VE GERİ YÜKLEME SİSTEMİ
# ============================================================================

class OtomatikKurtarma:
    """Açılır açılmaz yedek alır, tehlikeli virüs görürse otomatik geri yükler"""
    
    def __init__(self):
        self.yedek_klasoru = "TNG_Backups"
        self.yedek_dosyasi = None
        self.kurtarma_yapildi = False
        self.otomatik_koruma_aktif = True
        
        if not os.path.exists(self.yedek_klasoru):
            os.makedirs(self.yedek_klasoru)
    
    def log(self, mesaj, renk=Renk.BEYAZ):
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        print(c(f"[{timestamp}] {mesaj}", renk))
        
        if not os.path.exists("TNG_Logs"):
            os.makedirs("TNG_Logs")
        with open("TNG_Logs/otomatik_koruma.log", "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {mesaj}\n")
    
    # ========================================================================
    # 1. OTOMATİK YEDEK AL (Açılır açılmaz)
    # ========================================================================
    
    def otomatik_yedek_al(self):
        """Program açılır açılmaz otomatik yedek alır"""
        self.log("\n" + "═"*70, Renk.CYAN)
        self.log("💾 OTOMATİK YEDEK ALINIYOR...", Renk.YESIL)
        self.log("   (Program açılır açılmaz yedek alındı)", Renk.MAVI)
        self.log("═"*70, Renk.CYAN)
        
        zaman = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.yedek_dosyasi = os.path.join(self.yedek_klasoru, f"auto_backup_{zaman}.zip")
        
        # Yedeklenecek kritik bölgeler
        yedeklenecek_yerler = [
            os.path.expanduser("~\\Documents") if platform.system() == "Windows" else os.path.expanduser("~/Documents"),
            os.path.expanduser("~\\Desktop") if platform.system() == "Windows" else os.path.expanduser("~/Desktop"),
            os.path.expanduser("~\\Downloads") if platform.system() == "Windows" else os.path.expanduser("~/Downloads"),
            os.path.expanduser("~\\Pictures") if platform.system() == "Windows" else os.path.expanduser("~/Pictures"),
            os.path.expanduser("~\\Videos") if platform.system() == "Windows" else os.path.expanduser("~/Videos"),
        ]
        
        # EFI/MBR yedeği (Windows'ta)
        if platform.system() == "Windows":
            try:
                # MBR yedeği al (master boot record)
                with open(r"\\.\PhysicalDrive0", "rb") as f:
                    mbr = f.read(512)
                mbr_yedek = os.path.join(self.yedek_klasoru, f"mbr_backup_{zaman}.bin")
                with open(mbr_yedek, "wb") as f:
                    f.write(mbr)
                self.log(f"   ✅ MBR yedeği alındı: {mbr_yedek}", Renk.YESIL)
            except:
                self.log(f"   ⚠️ MBR yedeği alınamadı (yetki sorunu)", Renk.SARI)
            
            # Boot sector yedeği
            try:
                with open(r"\\.\PhysicalDrive0", "rb") as f:
                    f.seek(512)
                    boot_sector = f.read(512)
                boot_yedek = os.path.join(self.yedek_klasoru, f"boot_sector_{zaman}.bin")
                with open(boot_yedek, "wb") as f:
                    f.write(boot_sector)
                self.log(f"   ✅ Boot sector yedeği alındı", Renk.YESIL)
            except:
                pass
        
        # Dosya yedekleme
        yedeklenen = 0
        with zipfile.ZipFile(self.yedek_dosyasi, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for yer in yedeklenecek_yerler:
                if os.path.exists(yer):
                    try:
                        if os.path.isdir(yer):
                            for root, dirs, files in os.walk(yer):
                                for file in files:
                                    file_path = os.path.join(root, file)
                                    try:
                                        arcname = os.path.relpath(file_path, os.path.dirname(yer))
                                        zipf.write(file_path, arcname)
                                        yedeklenen += 1
                                    except:
                                        pass
                            self.log(f"   ✅ {os.path.basename(yer)}: yedeklendi", Renk.BEYAZ)
                    except:
                        pass
        
        dosya_boyutu = os.path.getsize(self.yedek_dosyasi)
        self.log(f"\n✅ OTOMATİK YEDEK TAMAMLANDI!", Renk.YESIL)
        self.log(f"   📂 Konum: {self.yedek_dosyasi}", Renk.BEYAZ)
        self.log(f"   💾 Boyut: {bytes_insan_oku(dosya_boyutu)}", Renk.BEYAZ)
        self.log(f"   📄 Yedeklenen dosya: {yedeklenen}", Renk.BEYAZ)
        
        return self.yedek_dosyasi
    
    # ========================================================================
    # 2. TEHLİKELİ VİRÜS TESPİTİ (Tüm tehlikeli virüsler)
    # ========================================================================
    
    def tehlikeli_virus_kontrol(self):
        """Windows XP Horror, Petya, SalineWin, MEMZ, Bootkit, EFI rootkit tespiti"""
        self.log("\n🔍 KRİTİK TEHDİT TARAMASI", Renk.KIRMIZI)
        self.log("   Windows XP Horror Edition | Petya | SalineWin | MEMZ | Bootkit | EFI", Renk.SARI)
        self.log("   Ransomware | Rootkit | Worm | Botnet | Keylogger | Cryptominer", Renk.SARI)
        
        bulunan_tehlikeler = []
        
        # Çalışan işlemleri kontrol et
        for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
            try:
                proc_name = proc.info['name'].lower() if proc.info['name'] else ''
                proc_exe = proc.info['exe'].lower() if proc.info['exe'] else ''
                proc_cmdline = ' '.join(proc.info['cmdline']).lower() if proc.info['cmdline'] else ''
                
                for virus_adi, virus_bilgi in TEHLIKELI_VIRUSLER.items():
                    # İsim kontrolü
                    for isim in virus_bilgi.get("isimler", []):
                        if isim.lower() in proc_name or isim.lower() in proc_cmdline or isim.lower() in proc_exe:
                            bulunan_tehlikeler.append({
                                'virus': virus_adi,
                                'isim': proc.info['name'],
                                'pid': proc.info['pid'],
                                'risk': virus_bilgi.get("risk", 100),
                                'etki': virus_bilgi.get("etki", "Sistem hasarı"),
                                'aciklama': virus_bilgi.get("aciklama", "Bilinmeyen tehdit")
                            })
                            self.log(f"   💀 {virus_adi.upper()}: {proc.info['name']}", Renk.KIRMIZI)
                            self.log(f"      → {virus_bilgi.get('aciklama', '')}", Renk.SARI)
                            break
                    
                    # Dosya ismi kontrolü
                    for dosya in virus_bilgi.get("dosya_isimleri", []):
                        if dosya.lower() in proc_name or dosya.lower() in proc_exe:
                            if not any(v['virus'] == virus_adi for v in bulunan_tehlikeler):
                                bulunan_tehlikeler.append({
                                    'virus': virus_adi,
                                    'isim': proc.info['name'],
                                    'pid': proc.info['pid'],
                                    'risk': virus_bilgi.get("risk", 100),
                                    'etki': virus_bilgi.get("etki", "Sistem hasarı"),
                                    'aciklama': virus_bilgi.get("aciklama", "Bilinmeyen tehdit")
                                })
                                self.log(f"   💀 {virus_adi.upper()}: {proc.info['name']}", Renk.KIRMIZI)
                                break
            except:
                continue
        
        # MBR/EFI değişikliği kontrolü (Windows)
        if platform.system() == "Windows":
            try:
                with open(r"\\.\PhysicalDrive0", "rb") as f:
                    mbr = f.read(512)
                
                # MBR signature kontrolü (55 AA olmalı)
                if len(mbr) >= 512 and (mbr[510] != 0x55 or mbr[511] != 0xAA):
                    bulunan_tehlikeler.append({
                        'virus': 'mbr_bozulma',
                        'isim': 'MBR',
                        'pid': None,
                        'risk': 100,
                        'etki': 'MBR bozulması tespit edildi!',
                        'aciklama': 'MBR signature bozulmuş olabilir - Petya veya bootkit enfeksiyonu'
                    })
                    self.log(f"   💀 MBR BOZULMASI TESPİT EDİLDİ!", Renk.KIRMIZI)
            except:
                pass
        
        return bulunan_tehlikeler
    
    # ========================================================================
    # 3. OTOMATİK GERİ YÜKLE (Kullanıcıya Sormadan)
    # ========================================================================
    
    def otomatik_geri_yukle(self, yedek_dosyasi=None):
        """Tehlikeli virüs bulunursa kullanıcıya SORMADAN otomatik geri yükler"""
        
        if yedek_dosyasi is None:
            yedek_dosyasi = self.yedek_dosyasi
        
        if not yedek_dosyasi or not os.path.exists(yedek_dosyasi):
            self.log("❌ Yedek dosyası bulunamadı! Geri yükleme yapılamadı.", Renk.KIRMIZI)
            return False
        
        self.log("\n" + "═"*70, Renk.KIRMIZI)
        self.log("💀💀💀 KRİTİK TEHDİT TESPİT EDİLDİ! 💀💀💀", Renk.KIRMIZI)
        self.log("═══════════════════════════════════════════════════════════════", Renk.KIRMIZI)
        self.log("⚠️  SİSTEM OTOMATİK OLARAK GERİ YÜKLENİYOR!", Renk.KIRMIZI)
        self.log("   (Kullanıcı müdahalesi olmadan)", Renk.SARI)
        self.log("═"*70, Renk.CYAN)
        
        self.kurtarma_yapildi = True
        
        # MBR yedeğini geri yükle (varsa)
        if platform.system() == "Windows":
            try:
                mbr_yedekleri = [f for f in os.listdir(self.yedek_klasoru) if f.startswith("mbr_backup_") and f.endswith(".bin")]
                if mbr_yedekleri:
                    en_son_mbr = max(mbr_yedekleri, key=lambda x: os.path.getctime(os.path.join(self.yedek_klasoru, x)))
                    with open(os.path.join(self.yedek_klasoru, en_son_mbr), "rb") as f:
                        mbr_data = f.read()
                    with open(r"\\.\PhysicalDrive0", "wb") as f:
                        f.write(mbr_data)
                    self.log(f"   ✅ MBR geri yüklendi!", Renk.YESIL)
            except:
                pass
        
        # Dosya yedekleme
        gecici_klasor = tempfile.mkdtemp()
        
        try:
            with zipfile.ZipFile(yedek_dosyasi, 'r') as zipf:
                zipf.extractall(gecici_klasor)
            
            self.log("\n📁 Dosyalar geri yükleniyor...", Renk.MAVI)
            
            for root, dirs, files in os.walk(gecici_klasor):
                for file in files:
                    kaynak = os.path.join(root, file)
                    hedef = kaynak.replace(gecici_klasor, "")
                    
                    if hedef.startswith(os.sep):
                        hedef = hedef[1:]
                    
                    if os.path.exists(hedef):
                        try:
                            shutil.copy2(kaynak, hedef)
                        except:
                            pass
            
            shutil.rmtree(gecici_klasor, ignore_errors=True)
            
            self.log("\n✅ SİSTEM BAŞARIYLA GERİ YÜKLENDİ!", Renk.YESIL)
            self.log("⚠️  Bilgisayar yeniden başlatılacak...", Renk.SARI)
            
            # Otomatik yeniden başlatma (kullanıcıya SORMADAN)
            self.log("\n🔄 10 saniye içinde otomatik yeniden başlatma yapılacak...", Renk.CYAN)
            
            for i in range(10, 0, -1):
                self.log(f"   ⏳ {i} saniye kaldı...", Renk.CYAN, end='\r')
                time.sleep(1)
            
            print()  # Yeni satır
            
            if platform.system() == "Windows":
                subprocess.run(["shutdown", "/r", "/t", "5", "/c", "TNG Antivirus - Kritik tehdit temizlendi, yeniden başlatılıyor..."])
            else:
                subprocess.run(["sudo", "reboot"])
            
            return True
            
        except Exception as e:
            self.log(f"❌ Geri yükleme hatası: {e}", Renk.KIRMIZI)
            shutil.rmtree(gecici_klasor, ignore_errors=True)
            return False
    
    # ========================================================================
    # 4. ANA KORUMA DÖNGÜSÜ (Açılır açılmaz başlar)
    # ========================================================================
    
    def koruma_baslat(self):
        """ANA KORUMA SİSTEMİ - Açılır açılmaz çalışır"""
        
        self.log("\n" + "═"*70, Renk.CYAN)
        self.log("🛡️ TNG OTOMATİK KORUMA SİSTEMİ BAŞLATILDI", Renk.YESIL)
        self.log("   ✅ Otomatik yedekleme AKTİF", Renk.MAVI)
        self.log("   ✅ Windows XP Horror Edition koruması AKTİF", Renk.MAVI)
        self.log("   ✅ Petya/SalineWin/MEMZ koruması AKTİF", Renk.MAVI)
        self.log("   ✅ Bootkit/EFI/Rootkit koruması AKTİF", Renk.MAVI)
        self.log("   ✅ Ransomware/Worm/Botnet koruması AKTİF", Renk.MAVI)
        self.log("   ✅ Keylogger/Cryptominer koruması AKTİF", Renk.MAVI)
        self.log("═"*70, Renk.CYAN)
        
        # ========== ADIM 1: AÇILIR AÇILMAZ YEDEK AL ==========
        yedek_dosyasi = self.otomatik_yedek_al()
        
        # ========== ADIM 2: BEKLEMEDEN TEHLİKELİ VİRÜS TARA ==========
        time.sleep(1)
        tehlikeler = self.tehlikeli_virus_kontrol()
        
        # ========== ADIM 3: TEHLİKELİ VİRÜS VARSA OTOMATİK GERİ YÜKLE ==========
        if tehlikeler:
            self.log("\n" + "═"*70, Renk.KIRMIZI)
            self.log(f"⚠️ {len(tehlikeler)} KRİTİK TEHLİKELİ VİRÜS TESPİT EDİLDİ!", Renk.KIRMIZI)
            self.log("═"*70, Renk.CYAN)
            
            for tehlike in tehlikeler:
                if tehlike['virus'] != 'mbr_bozulma':
                    self.log(f"   💀 {tehlike['virus'].upper()}: {tehlike['isim']}", Renk.KIRMIZI)
                    self.log(f"      → {tehlike['aciklama']}", Renk.SARI)
                    self.log(f"      → Risk: %{tehlike['risk']} | Etki: {tehlike['etki']}", Renk.BEYAZ)
            
            # KULLANICIYA SORMADAN OTOMATİK GERİ YÜKLE
            self.log("\n⚠️  Kullanıcıya sorulmadan otomatik geri yükleme başlatılıyor!", Renk.KIRMIZI)
            self.otomatik_geri_yukle(yedek_dosyasi)
        else:
            self.log("\n" + "═"*70, Renk.CYAN)
            self.log("✅ KRİTİK TEHDİT BULUNMADI!", Renk.YESIL)
            self.log("   Sistem güvende. Otomatik koruma aktif.", Renk.BEYAZ)
            self.log(f"   💾 Yedek konumu: {yedek_dosyasi}", Renk.MAVI)
            self.log("═"*70, Renk.CYAN)
        
        return tehlikeler

# ============================================================================
# TNG ANA SINIF
# ============================================================================

class TNGAntivirus:
    def __init__(self):
        self.versiyon = GELISTIRICI["versiyon"]
        self.kurtarma = OtomatikKurtarma()
        self.klasor_kontrol()
        self._banner_goster()
    
    def klasor_kontrol(self):
        klasorler = ["TNG_Logs", "TNG_Quarantine", "TNG_Reports", "TNG_Backups"]
        for klasor in klasorler:
            if not os.path.exists(klasor):
                os.makedirs(klasor)
    
    def _banner_goster(self):
        os.system('cls' if platform.system() == 'Windows' else 'clear')
        print(c("╔══════════════════════════════════════════════════════════════════════════╗", Renk.CYAN))
        print(c("║                                                                          ║", Renk.CYAN))
        print(c("║     ████████╗███╗   ██╗ ██████╗     █████╗ ███╗   ██╗████████╗██╗       ║", Renk.PEMBE))
        print(c("║     ╚══██╔══╝████╗  ██║██╔════╝    ██╔══██╗████╗  ██║╚══██╔══╝██║       ║", Renk.PEMBE))
        print(c("║        ██║   ██╔██╗ ██║██║         ███████║██╔██╗ ██║   ██║   ██║       ║", Renk.PEMBE))
        print(c("║        ██║   ██║╚██╗██║██║         ██╔══██║██║╚██╗██║   ██║   ╚═╝       ║", Renk.PEMBE))
        print(c("║        ██║   ██║ ╚████║╚██████╗    ██║  ██║██║ ╚████║   ██║   ██╗       ║", Renk.PEMBE))
        print(c("║        ╚═╝   ╚═╝  ╚═══╝ ╚═════╝    ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚═╝       ║", Renk.PEMBE))
        print(c("║                                                                          ║", Renk.CYAN))
        print(c("║        🛡️  TNG ANTİVİRÜS V{} - TAM OTOMATİK KORUMA                ║".format(self.versiyon), Renk.YESIL))
        print(c("║        💀  Windows XP Horror | Petya | SalineWin | MEMZ                 ║", Renk.KIRMIZI))
        print(c("║        🔥  Bootkit | EFI Rootkit | Ransomware | Worm | Botnet           ║", Renk.KIRMIZI))
        print(c("║        🔄  Açılır açılmaz yedek alır | Otomatik geri yükler             ║", Renk.TURUNCU))
        print(c("║                                                                          ║", Renk.CYAN))
        print(c("║        Geliştirici: TEKNOLOJIGOBLINI                                    ║", Renk.MAVI))
        print(c("║        📷 Instagram: @TEKNOLOJIGOBLINI                                  ║", Renk.TURUNCU))
        print(c("║        ▶️ YouTube: @teknolojigoblini                                    ║", Renk.KIRMIZI))
        print(c("║                                                                          ║", Renk.CYAN))
        print(c("╚══════════════════════════════════════════════════════════════════════════╝", Renk.CYAN))
        print()
    
    def calistir(self):
        """BAŞLAT - OTOMATİK KORUMA"""
        
        print(c("\n" + "═"*70, Renk.CYAN))
        print(c("🚀 TNG OTOMATİK KORUMA SİSTEMİ BAŞLATILIYOR...", Renk.YESIL))
        print(c("═"*70, Renk.CYAN))
        
        self.kurtarma.koruma_baslat()
        
        print(c("\n" + "═"*70, Renk.CYAN))
        print(c("📢 TEKNOLOJIGOBLINI - Güvenliğin Yeni Nesli", Renk.TURUNCU))
        print(c("📷 Instagram: @TEKNOLOJIGOBLINI", Renk.TURUNCU))
        print(c("▶️ YouTube: @teknolojigoblini", Renk.KIRMIZI))
        print(c("═"*70, Renk.CYAN))

def main():
    try:
        tng = TNGAntivirus()
        tng.calistir()
    except KeyboardInterrupt:
        print(c("\n\n⚠️ Program kullanıcı tarafından sonlandırıldı.", Renk.SARI))
    except Exception as e:
        print(c(f"\n❌ Beklenmeyen hata: {e}", Renk.KIRMIZI))
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()