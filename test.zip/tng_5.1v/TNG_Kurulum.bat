@echo off
title 💀 TNG ANTİVİRÜS - OTOMATİK KORUMA
color 0A
chcp 65001 >nul

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ⚠️ Yönetici yetkisi gerekiyor!
    timeout /t 2 /nobreak >nul
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                                                                          ║
echo ║     ████████╗███╗   ██╗ ██████╗     █████╗ ███╗   ██╗████████╗██╗       ║
echo ║     ╚══██╔══╝████╗  ██║██╔════╝    ██╔══██╗████╗  ██║╚══██╔══╝██║       ║
echo ║        ██║   ██╔██╗ ██║██║         ███████║██╔██╗ ██║   ██║   ██║       ║
echo ║        ██║   ██║╚██╗██║██║         ██╔══██║██║╚██╗██║   ██║   ╚═╝       ║
echo ║        ██║   ██║ ╚████║╚██████╗    ██║  ██║██║ ╚████║   ██║   ██╗       ║
echo ║        ╚═╝   ╚═╝  ╚═══╝ ╚═════╝    ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚═╝       ║
echo ║                                                                          ║
echo ║        🛡️  TNG ANTİVİRÜS V5.1 - OTOMATİK KURULUM                         ║
echo ║        💀  Windows XP Horror | Petya | SalineWin | MEMZ                  ║
echo ║        🔥  Bootkit | EFI Rootkit | Ransomware | Worm                     ║
echo ║        🔄  Açılır açılmaz yedek alır | Otomatik geri yükler             ║
echo ║                                                                          ║
echo ║        Geliştirici: TEKNOLOJIGOBLINI                                    ║
echo ║        📷 Instagram: @TEKNOLOJIGOBLINI                                  ║
echo ║        ▶️ YouTube: @teknolojigoblini                                    ║
echo ║                                                                          ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.

echo [1/3] 🔍 Python kontrol ediliyor...
python --version >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYTHON_VERSION=%%i
    echo    ✅ Python: %PYTHON_VERSION%
) else (
    echo    ⚠️ Python kuruluyor...
    curl -o python-installer.exe https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe --silent
    start /wait python-installer.exe /quiet InstallAllUsers=1 PrependPath=1
    del python-installer.exe
)

echo.
echo [2/3] 📦 pip güncelleniyor...
python -m pip install --upgrade pip >nul 2>&1

echo.
echo [3/3] 🔧 psutil kuruluyor...
pip install psutil --quiet >nul 2>&1

echo.
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                                                                          ║
echo ║     🚀 TNG OTOMATİK KORUMA BAŞLATILIYOR...                                ║
echo ║     ✅ Açılır açılmaz yedek alınacak                                      ║
echo ║     ✅ Windows XP Horror/Petya/SalineWin/MEMZ koruması aktif             ║
echo ║     ✅ Bootkit/EFI/Ransomware/Worm/Botnet koruması aktif                 ║
echo ║     ✅ Kritik tehditte otomatik geri yükleme aktif                       ║
echo ║                                                                          ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.

python TNG_Antivirus_V5.1.py

pause